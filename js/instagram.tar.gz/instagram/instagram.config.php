<?php
// Setup class
  $instagram = new Instagram(array(
    'apiKey'      => '56dbea395e1e4f018f02f90a8ef811c7',
    'apiSecret'   => 'fe06dff7add7486bbcf269ec996b6baf',
    'apiCallback' => 'http://www.senadorcollareco.com/instagram/success.php' // must point to success.php
  ));

?>
